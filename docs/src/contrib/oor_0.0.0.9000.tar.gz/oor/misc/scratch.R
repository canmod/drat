# Examples --------------------------

X = function() {
  self = Interface()
  self$f = function(x = numeric(1L)) return(numeric(1L))
  return_object(self, "X")
}
Y = function() {
  self = implements(X)
  self$f = function(x = numeric(1L)) return(x + 1)
  return_object(self, "Y")
}
x = X()
y = Y()
y$interface$f(10)
y$f(10)

A = function() {
  self = Trait()
  self$f = function(x) x + self$a
  return_object(self, "A")
}
B = function() {
  self = Trait()
  self$g = function(x) 1/x + self$a
  return_object(self, "B")
}
C = function() {
  self = inherit_from(Base, list(A, B))
  self$a = 1
  return_object(self, "C")
}

#C = function() {
#}

c = C()
a = A()
a$.public_method_names()
c$.public_method_names()
c$f(2)
c





validate_object = function(self, valid = function(self) TRUE) {
  # S4-style validity checking
  v = try(valid(self))
  if (!isTRUE(v)) stop(v)
}

clean_object = function(e) {
  # remove everything from the initializing
  # environment except self. this is a convenience
  # so that you don't need to worry about cleaning
  # up intermediate results from the class definition
  if (!is.environment(e)) stop("e must be an environment")
  if (identical(e, globalenv())) stop("e cannot be the global environment")
  if (environmentIsLocked(e)) stop("e is locked")
  if (!"self" %in% ls(e)) stop("e must contain self")
  if (!is.environment(e$self)) stop("self must be an environment")
  if (identical(e$self, globalenv())) stop("self cannot be the global environment")
  if (environmentIsLocked(e$self)) stop("self is locked")
  all_objects = ls(envir = e)
  objects_to_keep = "self"
  objects_to_clean = setdiff(all_objects, objects_to_keep)
  rm(list = objects_to_clean, envir = e)
}

return_object = function(self, class, valid = function(self) TRUE) {
  validate_object(self, valid)
  clean_object(parent.frame())
  structure(self, class = c(class, class(self)))
}

Base = function() {
  self = new.env(parent = emptyenv())
  structure(self, class = "Base")
}

print.Base = function(x, ...) {
  str(x)
  print(lsf.str(envir = x))
  invisible(x)
}

`$.Base` = function(x, name) {
  ## make sure that you get an error if
  ## a name cannot be found in self
  get(name, envir = x)
}


Trait1 = expression({
  self$f = function(x) {
    x + self$.a
  }
})
A = function(a) {
  self = Base()
  eval(Trait1)
  eval(Tra)
  self$.a = a
  return_object(self, "A")
}
a = A(1)
get("g", envir = a)
a[["g"]]
a$.a
a$f(1)


eval(Trait1)

Class1 = function() {
  self = Base()
  self$f = function(x) x
  return_object(self, "Class1")
}
Class2 = function() {
  self = Base()
  self$g = function(x) x^2
  return_object(self, "Class2")
}
x = Class1()
y = Class2()
identical(environment(x$f)$self, x)
identical(environment(y$g)$self, y)


inherit_traits = function(...) {
  self = new.env(parent = emptyenv())
  traits = list(...)
  for (trait in traits) {
    e = trait()
    for (nm in names(e)) {
      self[[nm]] = e[[nm]]
      environment(self[[nm]]) = environment()
    }
  }
  return_object(self, class = "Trait")
}

hh = inherit_traits(Class1, Class2)
ls(hh)
environment(hh$f)
environment(hh$g)


A = function() {
  self = Base()
  self$a = 1
  self$g = function(x) x^self$b
  return_object(self, "A")
}
B = function() {
  self = A()
  self$b = 2
  self$f = function(x) x + self$a
  return_object(self, "B")
}
b = B()
environment(b$g)
environment(b$f)

## Example and explanation



# in python we would write:
# class Child(Parent):
#   def __init__(self, *args, **kwargs):
#      super().__init__(*args, **kwargs)

# in this r style we would write:
# Child = function(...) {
#   self = Parent(...)
#   ...

# The main reason for more verbosity in Python is
# the option Python gives you to inherit without
# calling the __init__ method of the parent. in this
# example we end up calling it, but this need not be
# the case. in this r style inheritance and initialization
# are coupled. i personally think that this is fine,
# but not everyone will agree. i feel that the added
# flexibility of Python makes it too tempting to build
# overly complex class structures. if you need to
# decouple inheritance and initialization, I believe
# that this is a sign that you might not be S.O.L.I.D.

# there's more here as far as r-py differences go.
# this r pattern allows one to define methods before
# finishing initialization. on the other hand, this
# requires r programmers to refrain from calling methods
# in the initialization phase of the class definition,
# until they have defined those methods. this is because
# the class structure is being built out during every
# initialization call. is this bad?

AddN = function(n) {

  # step 1:
  # inherit from at least the base class defined above, containing
  # the clean method for signaling the end of the init method
  #  -- analogous to typing `Child(Parent)` in python --
  self = Base()

  # step 2:
  # the body of the init method
  #  -- analogous to the body of __init__ in python --
  #  -- the self$.n is analogous to the python convention
  #     of self._n for private fields and methods --
  self$.n = n

  # step 3:
  # define methods
  self$get_n = function() return(self$.n)
  self$set_n = function(value) self$.n = value
  self$compute = function(x) return(x + self$get_n())

  # step 4:
  # return newly created object
  return_object(
    self,
    "AddN",
    valid = function(x) {
      n = x$get_n()
      if (!is.numeric(n)) return("n must be numeric")
      if (length(n) != 1L) return("n must be length-1")
      TRUE
    }
  )
}

# step 5:
# define 'dunder-style' methods
print.AddN = function(x, ...) {
  print(paste("add", x$get_n(), "to x", sep = " "))
}

adder = AddN(pi)
print(adder)
adder$get_n()
adder$compute(10)
adder$set_n(10)
adder$get_n()
adder$compute(10)
print(adder)


AddN = function(n) {
  self = Base()

  stopifnot(is.numeric(n))
  stopifnot(length(n) == 1L)
  self$.n = n

  self$get_n = function() return(self$.n)
  self$set_n = function(value) self$.n = value
  self$compute = function(x) return(x + self$get_n())

  return_object(self, "AddN")
}

adder = AddN(5)
adder$get_n()
adder$set_n(10)
adder$get_n()
adder$compute(10)
print(adder)



