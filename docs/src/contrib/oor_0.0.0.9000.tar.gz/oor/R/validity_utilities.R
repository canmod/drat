pasten = function(...) paste("", paste(..., sep = "\n"), sep = "")
