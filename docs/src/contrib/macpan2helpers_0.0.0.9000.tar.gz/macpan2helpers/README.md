# macpan2helpers

This is a companion package to `macpan2`. Please [install that package](https://github.com/canmod/macpan2#installation) first.

## Installation

User should install with the following command:

```
remotes::install_github("canmod/macpan2helpers")
```
