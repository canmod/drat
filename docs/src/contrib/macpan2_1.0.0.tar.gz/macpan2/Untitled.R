library(macpan2)
mp_index(
  Epi = base::rep(c("S", "I", "R"), 2),
  Age = base::rep(c("young", "old"), each = 3)
)


mp_join(
  infection_flow_rates = mp_subset(rate, Epi = "lambda"),
  infectious_states = mp_subset(state, Epi = "I"),
  by = "Epi.Strain"
)

ii = mp_index(A = c("a", "a"), B = c("c", "d"), C = c("e", "f"))
mp_join(x = ii, y = ii, by = c("B.A"))

library(tidyxl)
gab = xlsx_cells("~/gab-mir/cdi_diphth_ca_1924-55_wk_prov-gab.xlsx")
mir = xlsx_cells("~/gab-mir/cdi_diphth_ca_1924-55_wk_prov-mir.xlsx")
all.equal(gab, mir)
all.equal(summary(gab), summary(mir))
nrow(gab)
nrow(mir)
ii = which(gab$character != mir$character)
jj = which(gab$numeric != mir$numeric)

gab[c(ii, jj), ]
mir[c(ii, jj), ]


sum(gab$numeric != mir$numeric, na.rm = TRUE)


state
macpan2:::initial_column_map(names(state), "crap")
Link(
  data.frame(group = rep("group", nrow(state$partition$frame()))),
  macpan2:::initial_column_map("group", "group"),
  macpan2:::initial_reference_index_list(state, "group"),
  macpan2:::initial_labelling_column_names_list(state$labelling_column_names, "group")
)
