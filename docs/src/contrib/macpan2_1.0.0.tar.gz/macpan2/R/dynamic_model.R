
# DynamicTMBModel = function(
#     before,
#     during,
#     after,
#     initial_matrices,
#     time_steps
#
#   ) {
#   self = Base()
#
#
#
#   return_object(self, "DynamicTMBModel")
# }
