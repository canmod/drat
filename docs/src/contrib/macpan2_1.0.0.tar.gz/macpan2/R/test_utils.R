constant_named_vector = function(const, nms) setNames(rep(const, length(nms)), nms)
