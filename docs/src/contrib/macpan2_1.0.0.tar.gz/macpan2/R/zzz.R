.onLoad <- function(lib, pkg) {
  options(
      macpan2_dll = "macpan2"
    #, macpan2_memoise = TRUE
  )
}
