Mapping = function(x_name, y_name) {
  self = Base()
  self.x_name = x_name
  self$y_name = y_name
  self$map = function(x, y) {

  }
  return_object(self, "Mapping")
}

