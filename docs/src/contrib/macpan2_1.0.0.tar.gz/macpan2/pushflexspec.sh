#!/bin/sh

make vignettes/flex_specs.html
make vignettes/flex_intro.html

# ------------------------------------------
# TODO: this git stuff needs to be smarter
# but for now it is convenient
git pull
#git add vignettes/flex_specs.rmd
#git commit -m "update specs"
#git push
# ------------------------------------------

scp vignettes/flex_specs.html swalk@ms.mcmaster.ca:~swalk/public_html/misc
scp vignettes/flex_intro.html swalk@ms.mcmaster.ca:~swalk/public_html/misc
