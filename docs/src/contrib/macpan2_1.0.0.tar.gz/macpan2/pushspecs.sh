#!/bin/sh

set -e  ## terminate on failure so that we don't keep trying to use git if pulls fail
git pull

Rscript -e "rmarkdown::render('vignettes/cpp_side.rmd')"
Rscript -e "rmarkdown::render('vignettes/composing_simulation_models.rmd')"
Rscript -e "rmarkdown::render('vignettes/elementwise_binary_operators.rmd')"
Rscript -e "rmarkdown::render('vignettes/model_definitions.rmd')"

# ------------------------------------------
# TODO: this git stuff needs to be smarter
# but for now it is convenient
git add vignettes/*.Rmd
git commit -m ":pencil: update specs [no ci] $1"
git push
# ------------------------------------------

scp vignettes/cpp_side.html swalk@ms.mcmaster.ca:~swalk/public_html/misc
scp vignettes/composing_simulation_models.html swalk@ms.mcmaster.ca:~swalk/public_html/misc
scp vignettes/elementwise_binary_operators.html swalk@ms.mcmaster.ca:~swalk/public_html/misc
scp vignettes/model_definitions.html swalk@ms.mcmaster.ca:~swalk/public_html/misc
