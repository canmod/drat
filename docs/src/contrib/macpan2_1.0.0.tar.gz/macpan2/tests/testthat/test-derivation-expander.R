#library(macpan2)
#box_model = Model(ModelFiles("inst/starter_models/seir_symp_vax"))
#expander = DerivationExpander(box_model)
#expander$expand_derivations()
