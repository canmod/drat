library(macpan2)
mp_index(Epi = c("S", "I", "R"))
