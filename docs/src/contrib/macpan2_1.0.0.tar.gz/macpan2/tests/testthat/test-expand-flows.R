test_that("it is possible to expand empty flow definition files", {

})
