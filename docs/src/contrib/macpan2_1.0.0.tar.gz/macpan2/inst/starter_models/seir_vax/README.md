---
title: "SEIR vaccination model"
index_entry: "An SEIR model that includes the effects of vaccination"
---
