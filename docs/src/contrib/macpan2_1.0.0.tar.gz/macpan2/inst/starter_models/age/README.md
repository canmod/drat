---
title: "basic ageing model"
index_entry: "aging model with six age groups and vital dynamics"
author: Darren Flynn-Primrose
---

This model does not include a pathogen, but can be multiplied by an epidemiological model (e.g. SIR) to produce an epidemiological model with age stratification.
