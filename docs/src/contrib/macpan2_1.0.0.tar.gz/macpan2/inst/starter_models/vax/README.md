---
title: "Basic vaccination model"
index_entry: "A simple vaccination model without waning"
---
