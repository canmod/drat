---
title: "Age factor model"
index_entry: "An age model for use with model products"
author : Darren Flynn-Primrose
---
