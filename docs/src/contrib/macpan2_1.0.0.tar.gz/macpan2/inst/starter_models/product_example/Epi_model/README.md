---
title: "Epi factor model"
index_entry: "An epi model for use with model products"
author: Darren Flynn-Primrose
---
