---
title: "SIR vaccination model"
index_entry: "an SIR model that includes vaccination"
---
