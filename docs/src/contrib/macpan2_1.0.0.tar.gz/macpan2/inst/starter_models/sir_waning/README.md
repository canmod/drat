---
title: "SIR with waning immunity"
index_entry: "a basic SIR model with a flow from R back to S"
author: Steve Walker
---

Endemic pathogens can sometimes be modelled by sending R back to S, thereby controlling susceptible depletion such that new infections to keep arising indefinitely.
