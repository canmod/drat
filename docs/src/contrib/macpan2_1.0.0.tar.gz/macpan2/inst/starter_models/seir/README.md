---
title: "basic SEIR"
index_entry: "vanilla epidemic model with an exposed class"
author: Steve Walker
---


