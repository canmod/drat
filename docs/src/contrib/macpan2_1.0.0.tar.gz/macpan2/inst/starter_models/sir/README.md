---
title: "basic SIR"
index_entry: "a very simple epidemic model"
author: Steve Walker
---

This is (nearly) the simplest possible 'vanilla' epidemic model, implemented as an example.
