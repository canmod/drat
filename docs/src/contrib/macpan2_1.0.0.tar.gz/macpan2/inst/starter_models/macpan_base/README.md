---
title: "MacPan base"
index_entry: "re-implementation of the McMaster group's COVID-19 model"
---

This model ...
