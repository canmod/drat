---
title: "SIR demonstration"
index_entry: "An SIR model with birth and death"
---
