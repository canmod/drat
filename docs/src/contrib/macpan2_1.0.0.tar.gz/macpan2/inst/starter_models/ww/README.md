---
title: "Wastewater model"
index_entry: "Macpan base with an additional wastewater component"
author: Maya Earn
---
