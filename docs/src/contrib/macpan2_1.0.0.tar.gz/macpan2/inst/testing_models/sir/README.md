---
title: "basic SIR"
index_entry: "a very simple epidemic model"
author: Steve Walker
---

Modification of the SIR starter model to test different
orders in the settings file.
